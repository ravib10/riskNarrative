$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"cbafa1c7-3946-4623-a220-7197255dd80d","feature":"1. Validate all the fields and their default states on the page.","scenario":"Validate user can enter the values in respective fields","start":1741296108592,"group":1,"content":"","tags":"@test6,","end":1741296118595,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});