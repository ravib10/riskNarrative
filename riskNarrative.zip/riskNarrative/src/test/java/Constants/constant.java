package Constants;

public class constant {

    public final static String chromeBrowser="chrome";
   public final static String blank="Blank";
   public final static String blankTextArea="Blank Textarea";
   public final static String disabledInput="Disabled input";
   public final static String readOnlyInput="Readonly input";
   public final static String drapDownSelect="Dropdown (select)";
   public final static String dropDownDataList="Dropdown (datalist)";
   public final static String textInput="Text input";
   public final static String password="Password";
   public final static String textArea="Textarea";
}
